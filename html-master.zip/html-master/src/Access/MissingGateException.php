<?php

namespace Styde\Html\Access;

class MissingGateException extends \Exception
{

}