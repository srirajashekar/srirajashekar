//tells Angular that we want to create a new module. We can then reference that module later on.
angular
  .module('app', []);